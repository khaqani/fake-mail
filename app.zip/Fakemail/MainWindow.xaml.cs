﻿using System;
using System.Net;
using System.Net.Mail;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Fakemail
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void btnSend_Click(object sender, RoutedEventArgs e)
        {
            int flag = 0;

            if (txtTo.Text.Trim().Length == 0) {
                flag = 0;
                txtbTo.Text = "Required";
                txtTo.Focus();
            }
            else if (!Regex.IsMatch(txtTo.Text, @"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}")) {
                flag = 0;
                txtbTo.Text = "Invalid";
                txtTo.Focus();
            }
            else {
                flag = 1;
                txtbTo.Text = "";
            }

            if (txtSMTP.Text.Trim().Length == 0) {
                flag = 0;
                txtbSMTP.Text = "*";
                txtSMTP.Focus();
            }

            if (txtPort.Text.Trim().Length == 0) {
                flag = 0;
                txtbPort.Text = "*";
                txtPort.Focus();
            }

            if (txtFrom.Text.Trim().Length == 0) {
                flag = 0;
                txtbFrom.Text = "Required";
                txtFrom.Focus();
            }

            if (txtSubject.Text.Trim().Length == 0) {
                flag = 0;
                txtbSubject.Text = "Required";
                txtSubject.Focus();
            }

            if (txtContent.Text.Trim().Length == 0) {
                flag = 0;
                txtbContent.Text = "Required";
                txtContent.Focus();
            }

            if (flag == 1)
            {
                var smptClient = new SmtpClient(txtSMTP.Text.Trim(), Convert.ToInt32(txtPort.Text));
                smptClient.Send(txtFrom.Text.Trim(), txtTo.Text.Trim(), txtSubject.Text, txtContent.Text);
                MessageBox.Show("Message Sent Successfully");
                txtFrom.Text = "";
                txtTo.Text = "";
                txtSubject.Text = "";
                txtContent.Text = "";
                txtTo.Focus();
            }
        }
        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            txtSMTP.Text = "";
            txtPort.Text = "";
            txtFrom.Text = "";
            txtTo.Text = "";
            txtSubject.Text = "";
            txtContent.Text = "";
            txtSMTP.Focus();

            txtbSMTP.Text = "";
            txtbPort.Text = "";
            txtbFrom.Text = "";
            txtbTo.Text = "";
            txtbSubject.Text = "";
            txtbContent.Text = "";
        }
    }
}
